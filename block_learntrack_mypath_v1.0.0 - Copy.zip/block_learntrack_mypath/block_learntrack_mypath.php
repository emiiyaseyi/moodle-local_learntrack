<?php
defined('MOODLE_INTERNAL') || die();

class block_learntrack_mypath extends block_base {

    public function init(): void { $this->title = 'My Learning Paths'; }
    public function has_config(): bool { return false; }
    public function instance_allow_multiple(): bool { return false; }
    public function applicable_formats(): array {
        return ['site-index'=>true,'my'=>true,'course-view'=>false];
    }

    public function get_content(): ?stdClass {
        global $USER, $DB, $CFG;
        if ($this->content !== null) return $this->content;
        $this->content = new stdClass();
        $this->content->text = $this->content->footer = '';

        if (!isloggedin() || isguestuser()) return $this->content;
        if (!file_exists($CFG->dirroot.'/local/learnpath/classes/data/helper.php')) return $this->content;
        require_once($CFG->dirroot.'/local/learnpath/classes/data/helper.php');

        $brand  = get_config('local_learnpath','brand_color') ?: '#1e3a5f';
        $bname  = get_config('local_learnpath','brand_name')  ?: 'LearnTrack';
        $sysctx = context_system::instance();
        $isAdmin= has_capability('local/learnpath:manage',       $sysctx, $USER->id);
        $isMgr  = has_capability('local/learnpath:viewdashboard',$sysctx, $USER->id) && !$isAdmin;

        $hex = ltrim($brand,'#');
        $r   = hexdec(substr($hex,0,2));
        $g   = hexdec(substr($hex,2,2));
        $b   = hexdec(substr($hex,4,2));

        // ── Determine which paths this user belongs to ────────────────────────
        // Authoritative source: local_learnpath_user_assign.
        // The upgrade migration (2026050108) seeds this table from course enrollment
        // for any path that had no explicit assignments, so every path now has records.
        // There is NO enrollment fallback — if a user is not in user_assign they do not
        // see the path, regardless of which Moodle courses they are enrolled in.

        $groups  = $DB->get_records('local_learnpath_groups', null, 'name ASC');
        $myGrps  = [];

        if (!empty($groups)) {
            if ($isAdmin) {
                // Admins always see every path
                $myGrps = $groups;
            } else {
                // One query: all paths this user is explicitly assigned to
                $assigned_gids = $DB->get_fieldset_select(
                    'local_learnpath_user_assign', 'groupid', 'userid = :uid', ['uid' => $USER->id]
                );
                $assigned_set = array_flip($assigned_gids);

                // One query: paths this user manages (managers also see their paths)
                $managed_set = [];
                if ($isMgr) {
                    $mgd = $DB->get_fieldset_select(
                        'local_learnpath_managers', 'groupid', 'userid = :uid', ['uid' => $USER->id]
                    );
                    $managed_set = array_flip($mgd);
                }

                foreach ($groups as $grp) {
                    if ($isMgr && isset($managed_set[$grp->id])) {
                        $myGrps[$grp->id] = $grp;
                    } elseif (isset($assigned_set[$grp->id])) {
                        $myGrps[$grp->id] = $grp;
                    }
                    // Not assigned and not a manager → not shown. No fallback.
                }
            }
        }

        // Hide block entirely for non-admin users with no assigned paths
        if (empty($myGrps) && !$isAdmin && !$isMgr) {
            // Return empty — block shows nothing, Moodle hides the block region
            return $this->content;
        }

        // Progress data — one batch query for all groups instead of per-group detail
        $totalDone=0; $totalAll=0; $overdueCt=0; $items=[];
        $prog_map = \local_learnpath\data\helper::get_user_path_progress(
            (int)$USER->id, array_keys($myGrps)
        );
        // Pre-load manager flags in one query
        $mgr_gids = $DB->get_fieldset_select(
            'local_learnpath_managers', 'groupid', 'userid = :uid', ['uid'=>$USER->id]
        );
        $mgr_set = array_flip($mgr_gids);

        foreach ($myGrps as $gid=>$grp) {
            $prog  = $prog_map[$gid] ?? null;
            $done  = $prog ? (int)$prog->completed_courses : 0;
            $total = $prog ? (int)$prog->total_courses     : 0;
            $pct   = $prog ? (int)$prog->overall_progress  : 0;
            $over  = $grp->deadline&&$grp->deadline<time()&&$pct<100;
            $days  = $grp->deadline?(int)ceil(($grp->deadline-time())/86400):null;
            $mgr   = isset($mgr_set[$gid]);
            $totalDone+=$done; $totalAll+=$total;
            if ($over) $overdueCt++;
            $items[]=compact('gid','grp','done','total','pct','over','days','mgr');
        }
        $overall = $totalAll>0?(int)round($totalDone/$totalAll*100):0;

        $myUrl   = new moodle_url('/local/learnpath/mypath.php');
        $dashUrl = new moodle_url('/local/learnpath/index.php');
        $ovUrl   = new moodle_url('/local/learnpath/overview.php');
        $bid     = 'ltrk-'.$this->instance->id;
        $prefKey = 'ltrk_lay_'.$USER->id;
        $circ    = round(2*M_PI*26,2);
        $off     = round($circ*(1-$overall/100),2);

        // Build HTML entirely in PHP - no ob_start to avoid Moodle output quirks
        $h = '';

        // CSS
        $h .= '<style>'
            . '#'.$bid.'{font-family:system-ui,-apple-system,sans-serif;font-size:13px}'
            . '#'.$bid.' .blk-sw{display:flex;gap:3px;justify-content:flex-end;margin-bottom:7px}'
            . '#'.$bid.' .blk-sw button{background:#f3f4f6;border:1.5px solid #e5e7eb;border-radius:6px;'
            .   'width:26px;height:26px;cursor:pointer;color:#9ca3af;font-size:.9rem;padding:0;line-height:1;transition:all .15s}'
            . '#'.$bid.' .blk-sw button.on{background:'.$brand.';border-color:'.$brand.';color:#fff}'
            // Header card
            . '#'.$bid.' .blk-head{background:linear-gradient(135deg,#0f172a,'.$brand.');border-radius:12px;'
            .   'padding:14px 16px;color:#fff;margin-bottom:9px;display:flex;justify-content:space-between;align-items:center}'
            . '#'.$bid.' .blk-head-brand{font-size:.6rem;font-weight:700;text-transform:uppercase;letter-spacing:.8px;opacity:.7;margin-bottom:3px}'
            . '#'.$bid.' .blk-head-title{font-size:.94rem;font-weight:800}'
            // Path card
            . '#'.$bid.' .blk-path{background:#fff;border:1px solid #e8eaed;border-radius:11px;'
            .   'margin-bottom:8px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.07);transition:box-shadow .2s}'
            . '#'.$bid.' .blk-path:hover{box-shadow:0 4px 16px rgba(0,0,0,.11)}'
            . '#'.$bid.' .blk-path-top{padding:11px 13px 0;display:flex;justify-content:space-between;align-items:flex-start;gap:6px}'
            . '#'.$bid.' .blk-pname{font-size:.84rem;font-weight:700;color:#111827;text-decoration:none;flex:1;line-height:1.3}'
            . '#'.$bid.' .blk-pname:hover{color:'.$brand.'}'
            . '#'.$bid.' .blk-ppct{font-size:.9rem;font-weight:900;flex-shrink:0}'
            . '#'.$bid.' .blk-bar{height:5px;background:#eef0f3;border-radius:100px;overflow:hidden;margin:7px 13px 0}'
            . '#'.$bid.' .blk-fill{height:100%;border-radius:100px;transition:width .5s}'
            . '#'.$bid.' .blk-pmeta{padding:5px 13px 9px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:3px}'
            . '#'.$bid.' .blk-meta-l{font-size:.67rem;color:#9ca3af}'
            // Badge
            . '#'.$bid.' .bb{display:inline-flex;align-items:center;font-size:.62rem;font-weight:700;padding:1px 6px;border-radius:100px;white-space:nowrap}'
            . '#'.$bid.' .bb-over{background:#fee2e2;color:#be123c}'
            . '#'.$bid.' .bb-warn{background:#fef3c7;color:#92400e}'
            . '#'.$bid.' .bb-done{background:#d1fae5;color:#065f46}'
            . '#'.$bid.' .bb-mgr{background:#ede9fe;color:#5b21b6}'
            . '#'.$bid.' .bb-np{background:#f3f4f6;color:#6b7280}'
            // Summary strip
            . '#'.$bid.' .blk-strip{background:rgba('.$r.','.$g.','.$b.',.07);border:1px solid rgba('.$r.','.$g.','.$b.',.12);'
            .   'border-radius:9px;padding:8px 12px;display:flex;justify-content:space-between;align-items:center;margin:6px 0}'
            . '#'.$bid.' .blk-strip-t{font-size:.75rem;font-weight:600;color:#374151}'
            // Buttons
            . '#'.$bid.' .blk-btns{display:flex;flex-direction:column;gap:6px;margin-top:8px}'
            . '#'.$bid.' .blk-bp{display:block;text-align:center;background:'.$brand.';color:#fff!important;'
            .   'font-size:.8rem;font-weight:700;padding:9px;border-radius:9px;text-decoration:none!important;transition:opacity .15s}'
            . '#'.$bid.' .blk-bp:hover{opacity:.87}'
            . '#'.$bid.' .blk-bs{display:block;text-align:center;background:#f3f4f6;color:#374151!important;'
            .   'font-size:.76rem;font-weight:700;padding:7px;border-radius:9px;text-decoration:none!important}'
            . '#'.$bid.' .blk-bs:hover{background:#e5e7eb}'
            . '#'.$bid.' .blk-mgr-l{font-size:.68rem;font-weight:700;color:'.$brand.'!important;text-decoration:none;float:right}'
            // List layout
            . '#'.$bid.' .lv-list .blk-lrow{display:flex;align-items:center;gap:7px;padding:6px 0;border-bottom:1px solid #f3f4f6}'
            . '#'.$bid.' .lv-list .blk-lname{font-size:.8rem;font-weight:600;color:#111827;text-decoration:none;'
            .   'min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
            . '#'.$bid.' .lv-list .blk-lname:hover{color:'.$brand.'}'
            . '#'.$bid.' .lv-list .blk-bar{margin:0 6px;flex:1;height:5px}'
            // Minimal
            . '#'.$bid.' .lv-min{text-align:center;padding:8px 4px}'
            . '#'.$bid.' .blk-empty{text-align:center;padding:18px;color:#9ca3af;font-size:.8rem}'
            . '</style>';

        // Layout switcher
        $h .= '<div id="'.$bid.'">';
        $h .= '<div class="blk-sw">';
        $h .= '<button title="Cards"   onclick="ltrkLay(\''.$bid.'\',\'cards\')">&#9635;</button>';
        $h .= '<button title="List"    onclick="ltrkLay(\''.$bid.'\',\'list\')">&#9776;</button>';
        $h .= '<button title="Minimal" onclick="ltrkLay(\''.$bid.'\',\'min\')">&#8942;</button>';
        $h .= '</div>';

        // Header (always visible)
        $h .= '<div class="blk-head">';
        $h .= '<div>';
        $h .= '<div class="blk-head-brand">&#128218; '.htmlspecialchars($bname).'</div>';
        $h .= '<div class="blk-head-title">My Learning Paths</div>';
        if ($overdueCt>0) $h .= '<div style="margin-top:4px"><span class="bb bb-over">&#9888; '.$overdueCt.' overdue</span></div>';
        $h .= '</div>';
        // SVG ring
        $h .= '<svg width="60" height="60" viewBox="0 0 60 60" style="flex-shrink:0">';
        $h .= '<circle cx="30" cy="30" r="26" fill="none" stroke="rgba(255,255,255,.2)" stroke-width="5"/>';
        $h .= '<circle cx="30" cy="30" r="26" fill="none" stroke="#fff" stroke-width="5"';
        $h .= ' stroke-dasharray="'.$circ.'" stroke-dashoffset="'.$off.'"';
        $h .= ' stroke-linecap="round" transform="rotate(-90 30 30)"/>';
        $h .= '<text x="30" y="25" text-anchor="middle" font-size="11" font-weight="800" fill="#fff">'.$overall.'%</text>';
        $h .= '<text x="30" y="35" text-anchor="middle" font-size="7" fill="rgba(255,255,255,.75)">overall</text>';
        $h .= '</svg>';
        $h .= '</div>';

        if (empty($myGrps)) {
            $h .= '<div class="blk-empty"><div style="font-size:1.6rem;margin-bottom:6px">&#128218;</div>No learning paths assigned.</div>';
        } else {
            // Split items into manager paths and learner-only paths
            $mgrItems     = [];
            $learnerItems = [];
            foreach ($items as $pi) {
                if ($pi['mgr'] || $isAdmin) {
                    $mgrItems[] = $pi;
                } else {
                    $learnerItems[] = $pi;
                }
            }

            // Helper: render one path card
            $renderCard = function(array $pi, bool $asMgr) use ($brand, $isMgr, $isAdmin): string {
                $clr  = $pi['pct']===100?'#10b981':($pi['pct']>0?'#f59e0b':'#d1d5db');
                $pu   = new moodle_url('/local/learnpath/mypath.php',['groupid'=>$pi['gid']]);
                $du   = new moodle_url('/local/learnpath/index.php', ['groupid'=>$pi['gid']]);
                $nm   = format_string($pi['grp']->name);
                $out  = '';
                if ($asMgr) {
                    // Manager card — accent border, direct dashboard link
                    $out .= '<div class="blk-path" style="border-left:3px solid '.$brand.';border-color:#7c3aed #e8eaed #e8eaed #7c3aed">';
                    $out .= '<div class="blk-path-top">';
                    $out .= '<a href="'.$du.'" class="blk-pname" style="color:#5b21b6">'.$nm.'</a>';
                    $out .= '<span class="bb bb-mgr" style="flex-shrink:0">&#9878; Manager</span>';
                    $out .= '</div>';
                    // Learner count from progress cache
                    $out .= '<div class="blk-pmeta" style="padding-top:7px">';
                    $out .= '<span class="blk-meta-l">&#128202; <a href="'.$du.'" style="color:var(--lt-accent);text-decoration:none;font-weight:700">View Learner Progress</a></span>';
                    $out .= '<a href="'.(new moodle_url('/local/learnpath/reminders.php',['groupid'=>$pi['gid']])).'" style="font-size:.64rem;color:#6b7280;text-decoration:none">&#128276; Reminders</a>';
                    $out .= '</div>';
                } else {
                    // Learner card — standard progress display
                    $badges = '';
                    if ($pi['pct']===100) $badges .= '<span class="bb bb-done">&#10003; Done</span>';
                    elseif ($pi['pct']===0) $badges .= '<span class="bb bb-np">Not started</span>';
                    elseif ($pi['over'])   $badges .= '<span class="bb bb-over">&#9888; Overdue</span>';
                    elseif ($pi['days']!==null&&$pi['days']<=7&&$pi['days']>0) $badges .= '<span class="bb bb-warn">&#9201; '.$pi['days'].'d left</span>';
                    elseif ($pi['days']!==null&&$pi['days']>0) $badges .= '<span class="bb" style="background:#f0fdf4;color:#15803d">&#128197; '.$pi['days'].'d</span>';

                    $out .= '<div class="blk-path">';
                    $out .= '<div class="blk-path-top">';
                    $out .= '<a href="'.$pu.'" class="blk-pname">'.$nm.'</a>';
                    $out .= '<span class="blk-ppct" style="color:'.$clr.'">'.$pi['pct'].'%</span>';
                    $out .= '</div>';
                    $out .= '<div class="blk-bar"><div class="blk-fill" style="width:'.$pi['pct'].'%;background:'.$clr.'"></div></div>';
                    $out .= '<div class="blk-pmeta">';
                    $out .= '<span class="blk-meta-l">'.$pi['done'].'/'.$pi['total'].' courses</span>';
                    $out .= '<div style="display:flex;gap:3px;align-items:center;flex-wrap:wrap">'.$badges.'</div>';
                    $out .= '</div>';
                }
                $out .= '</div>';
                return $out;
            };

            // Helper: render one list row
            $renderRow = function(array $pi, bool $asMgr) use ($brand): string {
                $clr = $pi['pct']===100?'#10b981':($pi['pct']>0?'#f59e0b':'#d1d5db');
                $url = $asMgr
                    ? new moodle_url('/local/learnpath/index.php',['groupid'=>$pi['gid']])
                    : new moodle_url('/local/learnpath/mypath.php',['groupid'=>$pi['gid']]);
                $nm = format_string($pi['grp']->name);
                $out  = '<div class="blk-lrow">';
                $out .= '<a href="'.$url.'" class="blk-lname" style="'.($asMgr?'color:#5b21b6':' ').'">';
                if ($asMgr) $out .= '&#9878; ';
                $out .= $nm . '</a>';
                if (!$asMgr) {
                    $out .= '<div class="blk-bar"><div class="blk-fill" style="width:'.$pi['pct'].'%;background:'.$clr.'"></div></div>';
                    $out .= '<span style="font-size:.76rem;font-weight:800;color:'.$clr.';min-width:30px;text-align:right">'.$pi['pct'].'%</span>';
                } else {
                    $out .= '<span style="font-size:.68rem;color:#7c3aed;font-weight:700;white-space:nowrap">Dashboard &#8594;</span>';
                }
                $out .= '</div>';
                return $out;
            };

            // Build card + list HTML with sections
            $cardsHtml = ''; $listHtml = '';
            $sectionHdr = function(string $icon, string $label, string $color) {
                return '<div style="font-size:.68rem;font-weight:800;text-transform:uppercase;letter-spacing:.6px;color:'.$color.';margin:10px 0 6px;display:flex;align-items:center;gap:5px">'.$icon.' '.$label.'</div>';
            };

            if (!empty($mgrItems)) {
                $cardsHtml .= $sectionHdr('&#9878;', 'Paths I Manage', '#5b21b6');
                $listHtml  .= $sectionHdr('&#9878;', 'Paths I Manage', '#5b21b6');
                foreach ($mgrItems as $pi) {
                    $cardsHtml .= $renderCard($pi, true);
                    $listHtml  .= $renderRow($pi, true);
                }
            }
            if (!empty($learnerItems)) {
                $cardsHtml .= $sectionHdr('&#128218;', 'My Learning Paths', $brand);
                $listHtml  .= $sectionHdr('&#128218;', 'My Learning Paths', $brand);
                foreach ($learnerItems as $pi) {
                    $cardsHtml .= $renderCard($pi, false);
                    $listHtml  .= $renderRow($pi, false);
                }
            }

            // Summary strip (learner overall only)
            $strip = '<div class="blk-strip">';
            $strip .= '<span class="blk-strip-t">'.$totalDone.'/'.$totalAll.' courses</span>';
            if ($overdueCt>0) $strip .= '<span class="bb bb-over">&#9888; '.$overdueCt.' overdue</span>';
            elseif ($overall===100) $strip .= '<span class="bb bb-done">&#127891; All done!</span>';
            $strip .= '</div>';

            // Buttons
            $profUrl = new moodle_url('/local/learnpath/myprofile.php');
            $btns  = '<div class="blk-btns">';
            if (!empty($learnerItems)) $btns .= '<a href="'.$myUrl.'" class="blk-bp">Continue Learning &#8594;</a>';
            $btns .= '<a href="'.$profUrl.'" class="blk-bs">&#128100; My Profile</a>';
            if ($isMgr||$isAdmin) $btns .= '<a href="'.$dashUrl.'" class="blk-bs">&#128202; Dashboard</a>';
            if ($isAdmin)         $btns .= '<a href="'.$ovUrl.'"  class="blk-bs">&#128225; Overview</a>';
            $btns .= '</div>';

            // Cards layout (default)
            $h .= '<div class="ltrk-lv lv-cards">'.$cardsHtml.$strip.$btns.'</div>';

            // List layout
            $listHead = '<div style="font-size:.72rem;font-weight:700;color:'.$brand.';text-transform:uppercase;'
                       .'letter-spacing:.5px;padding-bottom:5px;border-bottom:2px solid '.$brand.';margin-bottom:5px">'
                       .'Paths &mdash; '.$overall.'% overall</div>';
            $h .= '<div class="ltrk-lv lv-list" style="display:none">'.$listHead.$listHtml.$strip.$btns.'</div>';

            // Minimal layout
            $h .= '<div class="ltrk-lv lv-min" style="display:none">';
            $h .= '<div style="font-size:2.6rem;font-weight:900;color:'.$brand.';line-height:1">'.$overall.'%</div>';
            $h .= '<div style="font-size:.68rem;color:#9ca3af;text-transform:uppercase;letter-spacing:.5px;margin:3px 0 8px">Overall Progress</div>';
            $h .= '<div style="font-size:.76rem;color:#374151;margin-bottom:4px">'.$totalDone.'/'.$totalAll.' courses &middot; '.count($myGrps).' path(s)</div>';
            if ($overdueCt>0) $h .= '<div style="font-size:.72rem;font-weight:700;color:#be123c;margin-bottom:6px">&#9888; '.$overdueCt.' overdue</div>';
            $h .= $btns.'</div>';
        }

        $h .= '</div><!-- /blk -->';

        // Layout switcher JS — use js_init_code for Moodle 4.5+ CSP compliance
        global $PAGE;
        $lay_js  = '(function(){';
        $lay_js .= 'var K=' . json_encode($prefKey) . ',B=' . json_encode($bid) . ',Ls=["cards","list","min"];';
        $lay_js .= 'window.ltrkLay=function(bid,lay){';
        $lay_js .=   'var bl=document.getElementById(bid);if(!bl)return;';
        $lay_js .=   'bl.querySelectorAll(".ltrk-lv").forEach(function(el){';
        $lay_js .=     'el.style.display=el.classList.contains("lv-"+lay)?"":"none";});';
        $lay_js .=   'bl.querySelectorAll(".blk-sw button").forEach(function(btn,i){';
        $lay_js .=     'btn.classList.toggle("on",Ls[i]===lay);});';
        $lay_js .=   'try{localStorage.setItem(K,lay);}catch(e){}};';
        $lay_js .= 'document.addEventListener("DOMContentLoaded",function(){';
        $lay_js .=   'var s="cards";try{s=localStorage.getItem(K)||"cards";}catch(e){}';
        $lay_js .=   'ltrkLay(B,s);});';
        $lay_js .= '})();';
        $PAGE->requires->js_init_code($lay_js);

        $this->content->text = $h;
        return $this->content;
    }
}
